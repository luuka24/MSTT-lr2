public abstract class AtomicSentence extends Sentence {

}